const { ApplicationCommandType, EmbedBuilder, Webhook, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js");
const fs = require("fs");
async function ecloud(interaction, client) {
    const embed = new EmbedBuilder().setTitle(`<:white_salvar:1262295432130723842> — Painel de Config eCloud`)
        .setColor("Blue")
        .setDescription(` senhor(a) ${interaction.user}, Para adquirir o seu eCloud, compre-o separadamente em nosso servidor!`)


        const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setLabel('Adquirir')
            .setURL(`https://discord.com/channels/1237547289589846057/1241096543751245939`)
            .setStyle(5),
            new ButtonBuilder()
            .setCustomId("voltar1")
            .setLabel('Voltar')
            .setEmoji(`1262295432130723842`)
            .setStyle(2)
        )
 
        
    await interaction.update({ content: ``, embeds: [embed], ephemeral: true, components: [row2]/* row4, row3]*/ })
}


module.exports = {
    ecloud
}
