const { ActionRowBuilder, TextInputBuilder, TextInputStyle, InteractionType, ModalBuilder, EmbedBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../DataBaseJson");



async function FormasDePagamentos(interaction) {
    const embed = new EmbedBuilder()
    .setTitle(`Configurar formas de pagamento`)
    .setDescription(` você acessou minha aba de formas de pagamentos, configure abaixo.`)
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
    .setFooter(
        { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
    )
    .setTimestamp();

    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("configurarmercadopago")
                .setLabel('Configurar Mercado Pago')
                .setEmoji(`1225726880364105758`)
                .setStyle(2),
           new ButtonBuilder()
                .setCustomId("manualpagment")
                .setLabel('Configurar Pagamento Manual')
                .setEmoji(`1246106907597471764`)
                .setStyle(2),
             new ButtonBuilder()
                .setCustomId("voltaradawdwa")
                .setEmoji(`1262295432130723842`)
                .setStyle(2)

        )

    await interaction.update({ content: ``, embeds: [embed], ephemeral: true, components: [row2] })

}

async function PagamentoManual(interaction) {
    const embed = new EmbedBuilder()
    .setTitle(`Configurar Pagamento Manual`)
    .setDescription(`-  configure seu **pagamento manual**, abaixo.`)
    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
    .setFooter(
        { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
    )
    .setTimestamp();

if (configuracao.get(`pagamentos.SemiAutomatico.status`) == false) {
    embed.addFields(
        { name: `Sistema On/Off`, value: `\`🔴 Desativado\``, inline: false },
        { name: `Chave pix definida`, value: `\`🔴 Não configurado\``, inline: false },
        { name: `Tipo de Pagamento`, value: `\`🔴 Não configurado\``, inline: false },
        { name: `Pagamento manual`, value: `\`🔴 Não configurado\``, inline: false }
    );
}

    if (configuracao.get(`pagamentos.SemiAutomatico.status`) == true) {
        embed.addFields({ name: `Sistema On/Off`, value: `\`🟢 ${configuracao.get(`pagamentos.SemiAutomatico.status`)}\``, inline: false})
        embed.addFields({ name: `Chave pix definida`, value: `\`🟢 ${configuracao.get(`pagamentos.SemiAutomatico.pix`)}\``, inline: false})
        embed.addFields({ name: `Tipo de Pagamento`, value: `\`🟢 ${configuracao.get(`pagamentos.SemiAutomatico.tipofrm`)}\``, inline: false})
        embed.addFields({ name: `Pagamento manual`, value: `\`🟢 ${configuracao.get(`pagamentos.SemiAutomatico.msg`)}\``, inline: false})
    }


    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("ConfigurarPagamentoManual")
                .setLabel('Configurar Pagamento Manual')
                .setEmoji(`1237422647030190201`)
                .setStyle(2),
           new ButtonBuilder()
                .setCustomId("voltadawdawdawd")
                .setEmoji(`1262295432130723842`)
                .setStyle(2)

        )

    await interaction.update({ content: ``, embeds: [embed], ephemeral: true, components: [row2] })

}


module.exports = {
    FormasDePagamentos,
    PagamentoManual
}