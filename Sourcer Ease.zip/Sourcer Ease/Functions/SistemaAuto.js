const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');

async function automatico(interaction, client) {
    const embed = new EmbedBuilder()
        .setColor('#2b2d31')
        .setTitle('Configurações Automaticas')
        .setDescription(' aqui você pode configurar todas suas ações automaticas.')
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp();

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('autoclearfr')
                .setLabel('Configurar AutoClear')
                .setEmoji(`1241444361175040070`)
                .setStyle(2),
            new ButtonBuilder()
                .setCustomId('frcabulusoacima')
                .setLabel('Mensagens Automaticas')
                .setDisabled(true)
                .setEmoji(`1241444370327273492`)
                .setStyle(2),
        );
        const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId('autorolecaralho')
            .setLabel('Configurar AutoRole')
            .setEmoji(`1241444362655764521`)
            .setStyle(2),
        new ButtonBuilder()
            .setCustomId('voltar1')
            .setEmoji(`1262295432130723842`)
            .setStyle(2)
        )

    interaction.update({ embeds: [embed], components: [row, row2], ephemeral: true });
      }

module.exports = {
    automatico,
};
