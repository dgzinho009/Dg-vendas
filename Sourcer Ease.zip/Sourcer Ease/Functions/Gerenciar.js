const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder, InteractionType } = require("discord.js");
const Discord = require("discord.js")

async function Gerenciar(interaction, client) {


    const row1 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("configcargos")
                .setLabel('Configurar Cargos')
                .setEmoji(`1262295428070903829`)
                .setStyle(2),

            new ButtonBuilder()
                .setCustomId("personalizarcanais")
                .setLabel('logs Geral')
                .setEmoji(`1262295428070903829`)
                .setStyle(2),


        )

    const row2 = new ActionRowBuilder()
        .addComponents(

            new ButtonBuilder()
                .setCustomId("formasdepagamentos")
                .setLabel('Formas de pagamento')
                .setEmoji(`1262544431458943119`)
                .setStyle(1),

        )

    const row3 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("voltar1")
                .setEmoji(`1262295432130723842`)
                .setStyle(2)
        )
        

    if (interaction.message == undefined) {
        interaction.reply({ embeds: [
            new EmbedBuilder()
            .setDescription(`- **Configurações Avançadas**\n - Seja **bem-vindo** ao sistema de configuração avançada, abaixo teremos os botões que você pode alterar da sua forma.`)
            .setColor("#2b2d31")
        ], components: [row1, row2, row3], content: `` })
    } else {
        interaction.update({ embeds: [
            new EmbedBuilder()
            .setDescription(`- **Configurações Avançadas**\n - Seja **bem-vindo** ao sistema de configuração avançada, abaixo teremos os botões que você pode alterar da sua forma.`)
            .setColor("#2b2d31")
        ], components: [row1, row2, row3], content: `` })
    }

}


module.exports = {
    Gerenciar
}
