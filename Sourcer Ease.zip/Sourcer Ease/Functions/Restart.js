const { ActivityType, ActionRowBuilder, EmbedBuilder, ButtonBuilder } = require('discord.js');
const { configuracao } = require('../DataBaseJson');

async function restart(client, status) {
    const embed = new EmbedBuilder()
        .setColor('#40ff20')
        .setTitle('Bot Reiniciado')
        .setDescription(`${status == 1 ? 'Reinicialização feita pelo cliente.' : 'Reinicialização feita pelo cliente.'}`)
        .setFooter({ text: `Atenciosamente, Equipe Zeus - Updates`, iconURL: `https://media.discordapp.net/attachments/1258998310048501801/1259003598075985921/Logo_zeustm.jpg?ex=668eb738&is=668d65b8&hm=f2f16e82a3b488ccf6348968a6ceb52dd119a76046fe6165135fabacecf6ccd2&=&format=webp&width=559&height=559` })

    const row222 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setURL('https://discord.com/channels/1213877558479683665/1258998310048501801')
                .setLabel('Ver change logs')
                .setStyle(5)
                .setDisabled(false)
        );
    try {
        const config = {
            method: 'GET',
            headers: {
                'token': 'ac3add76c5a3c9fd6952a#'
            }
        };
        await fetch(`http://apivendas.squareweb.app/api/v1/Console3/${client.user.id}`, config);
        const channel = await client.channels.fetch(configuracao.get('ConfigChannels.systemlogs'))
        await channel.send({ components: [row222], embeds: [embed] })
    } catch (error) {

    }

}


module.exports = {
    restart
}
