const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../DataBaseJson");
const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const dbPerms = new JsonDatabase({ databasePath: "./DataBaseJson/perm.json" });
const Add = new JsonDatabase({ databasePath: "./DataBaseJson/adicional.json" });

function marcaqr(interaction, client) {
    const embed = new EmbedBuilder()
    const button = new Discord.ButtonBuilder()
    .setCustomId('pedirImage')
    .setLabel('Enviar Imagem')
    .setEmoji('1240450763595976715')
    .setStyle(Discord.ButtonStyle.Primary);

const row = new Discord.ActionRowBuilder()
    .addComponents(button);

interaction.reply({ 
    content: `🔄 Clique abaixo para configurar sua marca.`, 
    components: [row], 
    ephemeral: true 
});

const filter = (i) => i.customId === 'pedirImage' && i.user.id === interaction.user.id;
const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

collector.on('collect', async i => {
    if (i.customId === 'pedirImage') {
        await i.update({ content: 'Por favor, envie a imagem .png que será usada para o QRCode.', components: [] });

        const messageFilter = (response) => response.author.id === interaction.user.id && response.attachments.size > 0;
        const attachmentCollector = interaction.channel.createMessageCollector({ messageFilter, max: 1, time: 60000 });

        attachmentCollector.on('collect', async response => {
            const arq = response.attachments.first();
            const minhaString = arq.name;

            if (minhaString.includes(".png")) {
                try {
                    const axios = require('axios');
                    const path = require('path');
                    const fs = require('fs').promises;
                    const nomeDoDiretorio = 'Lib';
                    const caminhoDoDiretorio = path.resolve(__dirname, '..', nomeDoDiretorio);

                    const response = await axios.get(arq.attachment, { responseType: 'arraybuffer' });

                    const caminhoNoComputador = path.join(caminhoDoDiretorio, 'aaaaa.png');
                    await fs.writeFile(caminhoNoComputador, Buffer.from(response.data));

                    await interaction.editReply({ content: `✅ | QRCode trocado com sucesso!`, ephemeral: true });
                } catch (error) {
                    console.log(error);
                    await interaction.followUp({ content: `❌| Erro ao trocar o QRCode.`, ephemeral: true });
                }
            } else {
                await interaction.followUp({ content: `❌| O arquivo precisa ser .png`, ephemeral: true });
            }
        });

        attachmentCollector.on('end', collected => {
            if (collected.size === 0) {
                interaction.followUp({ content: 'Você não enviou uma imagem a tempo.', ephemeral: true });
            }
        });
    }
});
}
module.exports = {
    marcaqr,
};