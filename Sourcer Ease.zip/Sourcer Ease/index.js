const { GatewayIntentBits, Client, Collection, Partials } = require("discord.js");
const { AtivarIntents } = require("./Functions/StartIntents");
const express = require("express");
const app = express();
const client = new Client({
    intents: Object.keys(GatewayIntentBits),
    partials: Object.keys(Partials)
});

const config = require("./config.json");
const { port } = config;

const estatisticasStormInstance = require("./Functions/VariaveisEstatisticas");
const EstatisticasStorm = new estatisticasStormInstance();
module.exports = { EstatisticasStorm };

AtivarIntents();

const events = require('./Handler/events');
const slash = require('./Handler/slash');

slash.run(client);
events.run(client);

client.slashCommands = new Collection();

client.login(config.token);

process.on('unhandRejection', (reason, promise) => {
  console.log(`🚫 Erro Detectado:\n\n` + reason, promise);
});

process.on('uncaughtException', (error, origin) => {
  console.log(`🚫 Erro Detectado:\n\n` + error, origin);
});

try {
  app.listen({
    host: "0.0.0.0",
    port: process.env.PORT ? Number(process.env.PORT) : port
  });
} finally {
  console.log("Iniciando Processo");
  console.log("Processo Iniciado");
}