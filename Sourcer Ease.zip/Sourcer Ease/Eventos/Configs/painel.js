
const Discord = require("discord.js")
const { RoleSelectMenuBuilder, EmbedBuilder, InteractionType, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js")
const { PainelMember, Painel, Gerenciar2, mensagemauto, mensagemautoedit, autorole, PainelPrincipal } = require("../../Functions/Painel");
const { CreateStore } = require("../../Functions/createloja.js");
const { Gerenciar } = require("../../Functions/Gerenciar");
const { automatico } = require("../../Functions/SistemaAuto");
const { AutoClear } = require("../../Functions/AutoClear");
/* const { infosauth } = require("../../Functions/infosauth");
const { configauth } = require("../../Functions/eCloudConfigs");
const { infoauth } = require("../../Functions/infoauth");
const { automatico } = require("../../Functions/SistemaAuto"); */
const { ecloud } = require("../../Functions/eCloudConfig");
const { marcaqr } = require("../../Functions/Marca");
const { JsonDatabase } = require("wio.db");
const perms = new JsonDatabase({ databasePath: "./DataBaseJson/perm.json" });

const { ConfigRoles } = require("../../Functions/ConfigRoles");
const { msgbemvindo } = require("../../Functions/MensagemBemVindo");
const { EstatisticasStorm } = require("../../index.js");
const { profileuser } = require("../../Functions/profile");
const { relikia, produtos, configuracao, tickets } = require("../../DataBaseJson");
const { Posicao1 } = require("../../Functions/PosicoesFunction.js");
const { painelTicket } = require("../../Functions/PainelTickets.js");
const { CreateMessageTicket, Checkarmensagensticket } = require("../../Functions/CreateMensagemTicket.js");
const { CreateTicket } = require("../../Functions/CreateTicket.js");
const { GerenciarCampos2 } = require("../../Functions/GerenciarCampos.js");
const { MessageStock } = require("../../Functions/ConfigEstoque.js");

module.exports = {
    name: 'interactionCreate',

    run: async (interaction, client) => {

        if (interaction.type == Discord.InteractionType.ModalSubmit) {


            if (interaction.customId == 'criarmsgautomodal') {
                const title = interaction.fields.getTextInputValue("title") || null;
                const desc = interaction.fields.getTextInputValue("desc");
                const banner = interaction.fields.getTextInputValue("banner") || null;
                const channel = interaction.fields.getTextInputValue("channel");
                const time = parseInt(interaction.fields.getTextInputValue("time"));
                const chnchk = interaction.guild.channels.cache.get(channel);
                if (!chnchk) return interaction.reply({ content: `❌ | Não existe um canal com ID dê \`${channel}\``, ephemeral: true });
                if (isNaN(time)) return interaction.reply({ content: `❌ | Coloque apenas numeros na quantidade de Segundos`, ephemeral: true });
                if (time < 1) return interaction.reply({ content: `${emoji(12)} | Coloque acima de \`1 Segundo\``, ephemeral: true });
                await interaction.deferUpdate();
                try {
                    await interaction.followUp({
                        content: `${interaction.user}`,
                        embeds: [
                            new EmbedBuilder()
                                .setAuthor({ name: "Previa da Embed" })
                                .setTitle(title)
                                .setDescription(desc)
                                .setColor(await relikia.get("cor"))
                                .setImage(banner)
                        ],
                        components: [
                            new ActionRowBuilder()
                                .addComponents(
                                    new ButtonBuilder()
                                        .setCustomId("oasidnmasiod123asniud")
                                        .setLabel("Mensagem Automatica")
                                        .setStyle(2)
                                        .setDisabled(true)
                                )
                        ],
                        ephemeral: true
                    }).then(async () => {
                        await relikia.push("automod.mensagem_auto.mensagem", {
                            title,
                            desc,
                            banner,
                            channel,
                            tempo: Number(time),
                            ind: Number(await relikia.get("automod.mensagem_auto.mensagem").length + 1)
                        });
                        const mensagem = await relikia.get("automod.mensagem_auto");
                        const status = !mensagem.system ? "`Ativada`" : "`Desativada`";
                        let ok = mensagem.mensagem.map((a, index) => { return `(\`${index + 1}\`) - ${a.desc}` })
                            .join("\n");
                        if (mensagem.mensagem.length <= 0) {
                            ok = "Nenhuma mensagem definida!";
                        };
                        const userid = interaction.user.id;
                        mensagemauto(interaction, client);
                    })
                } catch (err) {
                    interaction.followUp({
                        content: `${emoji(29)} | Ocorreu um erro...\n\n**Mensagem do erro:** \`\`\`${err.message}\`\`\``,
                        ephemeral: true
                    })
                }

            }


            if (interaction.customId == 'deletemsgautomodal') {
                const text = parseInt(interaction.fields.getTextInputValue("text"));
                const valor = text - 1;
                if (isNaN(text)) return interaction.reply({ content: `❌ | Coloque apenas numeros.`, ephemeral: true });
                if (text <= 0) return interaction.reply({ content: `❌ | Coloque um Valor Acima de \`0\`.`, ephemeral: true });
                if (valor > await relikia.get("automod.mensagem_auto.mensagem").length) return interaction.reply({ content: `❌ | Coloque um Valor Abaixo dê \`${await relikia.get("automod.mensagem_auto.mensagem").length}\`.`, ephemeral: true });
                const a = await relikia.get("automod.mensagem_auto.mensagem");
                await a.splice(Number(valor), 1)[0];
                await relikia.set("automod.mensagem_auto.mensagem", a);
                mensagemauto(interaction, client);
            }


            if (interaction.customId == 'sdaju11111231idsj1233js123dua123') {
                let NOME = interaction.fields.getTextInputValue('tokenMP');
                let PREDESC = interaction.fields.getTextInputValue('tokenMP4');
                let DESC = interaction.fields.getTextInputValue('tokenMP3');
                let BANNER = interaction.fields.getTextInputValue('tokenMP5');
                let EMOJI = interaction.fields.getTextInputValue('tokenMP6');

                NOME = NOME.replace('.', '');
                PREDESC = PREDESC.replace('.', '');

                if (tickets.get(`tickets.funcoes.${NOME}`) !== null) {
                    return interaction.reply({ content: `❌| Já existe um bloco com esse nome!`, ephemeral: true });
                }

                if (NOME.length > 32) {
                    return interaction.reply({ content: `❌| O nome não pode ter mais de 32 caracteres!`, ephemeral: true });
                } else {
                    tickets.set(`tickets.funcoes.${NOME}.nome`, NOME)
                }

                if (PREDESC.length > 64) {
                    return interaction.reply({ content: `❌| A pré descrição não pode ter mais de 64 caracteres!`, ephemeral: true });
                } else {
                    tickets.set(`tickets.funcoes.${NOME}.predescricao`, PREDESC)
                }

                if (DESC !== '') {
                    if (DESC.length > 1024) {
                        return interaction.reply({ content: `❌| A descrição não pode ter mais de 1024 caracteres!`, ephemeral: true });
                    } else {
                        tickets.set(`tickets.funcoes.${NOME}.descricao`, DESC)
                    }
                }

                if (BANNER !== '') {
                    const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;
                    if (!urlRegex.test(BANNER)) {
                        tickets.set(`tickets.funcoes.${NOME}.banner`, BANNER)
                        return interaction.reply({ message: dd, content: `❌| Você escolheu incorretamente a URL do banner!`, ephemeral: true });
                    } else {
                        tickets.set(`tickets.funcoes.${NOME}.banner`, BANNER)
                    }
                }

                if (EMOJI !== '') {
                    const emojiRegex = /^<:.+:\d+>$|^<a:.+:\d+>$|^\p{Emoji}$/u;
                    if (!emojiRegex.test(EMOJI)) {
                        return interaction.reply({ content: `❌| Você escolheu incorretamente o emoji!`, ephemeral: true });
                    } else {
                        tickets.set(`tickets.funcoes.${NOME}.emoji`, EMOJI)
                    }
                }

                await painelTicket(interaction)

                interaction.followUp({ content: `✅ | Bloco adicionado com sucesso!`, ephemeral: true });




            }

            if (interaction.customId == '0-89du0awd8awdaw8daw') {

                let TITULO = interaction.fields.getTextInputValue('tokenMP');
                let DESC = interaction.fields.getTextInputValue('tokenMP2');
                let BANNER = interaction.fields.getTextInputValue('tokenMP3');
                let COREMBED = interaction.fields.getTextInputValue('tokenMP5');

                if (TITULO.length > 256) {
                    return interaction.reply({ content: `❌| O título não pode ter mais de 256 caracteres!`, ephemeral: true });
                }
                if (DESC.length > 1024) {
                    return interaction.reply({ content: `❌| A descrição não pode ter mais de 1024 caracteres!`, ephemeral: true });
                }

                if (COREMBED !== '') {
                    const hexColorRegex = /^#?([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})$/;
                    if (!hexColorRegex.test(COREMBED)) {

                        return interaction.reply({ content: `❌Código Hex Color \`${COREMBED}\` inváldo, tente pegar [nesse site.](https://www.google.com/search?q=color+picker&oq=color+picker) `, ephemeral: true });
                    } else {
                        tickets.set(`tickets.aparencia.color`, COREMBED)
                    }
                }



                if (BANNER !== '') {
                    const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;
                    if (!urlRegex.test(BANNER)) {

                        return interaction.reply({ message: dd, content: `❌| Você escolheu incorretamente a URL do banner!`, ephemeral: true });
                    } else {
                        tickets.set(`tickets.aparencia.banner`, BANNER)
                    }
                }

                if (TITULO !== '') {
                    tickets.set(`tickets.aparencia.title`, TITULO)
                } else {
                    tickets.delete(`tickets.aparencia.title`)
                }

                if (DESC !== '') {
                    tickets.set(`tickets.aparencia.description`, DESC)
                } else {
                    tickets.delete(`tickets.aparencia.description`)
                }

                await painelTicket(interaction)


            }




            if (interaction.customId === 'aslfdjauydvaw769dg7waajnwndjo') {

                let VALOR = interaction.fields.getTextInputValue('tokenMP');
                let CARGO = interaction.fields.getTextInputValue('tokenMP2');


                if (CARGO !== '' && VALOR !== '') {
                    const role = await interaction.guild.roles.fetch(CARGO);

                    if (role === null) {
                        return interaction.reply({ content: `❌| Você escolheu incorretamente o ID do cargo!`, ephemeral: true });
                    }

                    if (isNaN(VALOR)) {
                        return interaction.reply({ content: `❌| Você escolheu incorretamente o valor!`, ephemeral: true });
                    }

                    configuracao.set(`posicoes.pos1.role`, CARGO);
                    configuracao.set(`posicoes.pos1.valor`, VALOR);
                } else {
                    configuracao.delete(`posicoes.pos1`);
                }

                await Posicao1(interaction, client)
                //  interaction.followUp({ content: `✅ | Posição definida com sucesso!`, ephemeral: true });

            }

            if (interaction.customId === 'awiohdbawudwdwhduawdnuaw') {

                let VALOR = interaction.fields.getTextInputValue('tokenMP');
                let CARGO = interaction.fields.getTextInputValue('tokenMP2');


                if (CARGO !== '' && VALOR !== '') {
                    const role = await interaction.guild.roles.fetch(CARGO);

                    if (role === null) {
                        return interaction.reply({ content: `❌| Você escolheu incorretamente o ID do cargo!`, ephemeral: true });
                    }

                    if (isNaN(VALOR)) {
                        return interaction.reply({ content: `❌| Você escolheu incorretamente o valor!`, ephemeral: true });
                    }

                    configuracao.set(`posicoes.pos2.role`, CARGO);
                    configuracao.set(`posicoes.pos2.valor`, VALOR);
                } else {
                    configuracao.delete(`posicoes.pos2`);
                }

                await Posicao1(interaction, client)
                // interaction.followUp({ content: `✅ | Posição definida com sucesso!`, ephemeral: true });
            }

            if (interaction.customId === 'uy82819171h172') {

                let VALOR = interaction.fields.getTextInputValue('tokenMP');
                let CARGO = interaction.fields.getTextInputValue('tokenMP2');

                if (CARGO !== '' && VALOR !== '') {
                    const role = await interaction.guild.roles.fetch(CARGO);

                    if (role === null) {
                        return interaction.reply({ content: `❌| Você escolheu incorretamente o ID do cargo!`, ephemeral: true });
                    }

                    if (isNaN(VALOR)) {
                        return interaction.reply({ content: `❌| Você escolheu incorretamente o valor!`, ephemeral: true });
                    }

                    configuracao.set(`posicoes.pos3.role`, CARGO);
                    configuracao.set(`posicoes.pos3.valor`, VALOR);
                } else {
                    configuracao.delete(`posicoes.pos3`);
                }

                await Posicao1(interaction, client)
                // interaction.followUp({ content: `✅ | Posição definida com sucesso!`, ephemeral: true });
            }


        }

        if (interaction.isAutocomplete()) {
            if (interaction.commandName == 'manage_item') {
                const nomeDigitado = interaction.options.getFocused().toLowerCase();
                const produtosFiltrados = produtos.filter(x => x.ID.toLowerCase().includes(nomeDigitado));
                const produtosSelecionados = produtosFiltrados.slice(0, 25);

                const config = produtosSelecionados.flatMap(x => {
                    const matchingFields = x.data.Campos.filter(iterator =>
                        iterator.Nome.toLowerCase().includes(nomeDigitado)
                    );

                    return matchingFields.map(iterator => ({
                        name: `🧵 ${x.data.Config.name} ➔ ${iterator.Nome}`,
                        value: `${x.ID}_${iterator.Nome}`,
                    }));
                });

                const response = config.length > 0
                    ? config
                    : [{ name: 'Nenhum produto registrado foi encontrado', value: 'nada' }];

                interaction.respond(response);
            }

            if (interaction.commandName == 'manage_stock') {
                const nomeDigitado = interaction.options.getFocused().toLowerCase();
                const produtosFiltrados = produtos.filter(x => x.ID.toLowerCase().includes(nomeDigitado));
                const produtosSelecionados = produtosFiltrados.slice(0, 25);

                const config = produtosSelecionados.flatMap(x => {
                    const matchingFields = x.data.Campos.filter(iterator =>
                        iterator.Nome.toLowerCase().includes(nomeDigitado)
                    );

                    return matchingFields.map(iterator => ({
                        name: `🧵 ${x.data.Config.name} ➔ ${iterator.Nome}`,
                        value: `${x.ID}_${iterator.Nome}`,
                    }));
                });

                const response = config.length > 0
                    ? config
                    : [{ name: 'Nenhum produto registrado foi encontrado', value: 'nada' }];

                interaction.respond(response);
            }

            if (interaction.commandName == 'manage_product') {
                var nomeDigitado = interaction.options.getFocused().toLowerCase();
                var produtosFiltrados = produtos.filter(x => x.ID.toLowerCase().includes(nomeDigitado));
                var produtosSelecionados = produtosFiltrados.slice(0, 25);

                const config = produtosSelecionados.map(x => {
                    return {
                        name: `🧵 ${x.data.Config.name}`,
                        value: `${x.ID}`
                    }
                })

                interaction.respond(!config.length ? [{ name: `Nenhum produto registrado foi encontrado`, value: `nada` }] : config);

            }
        }

        let valorticket
        if (interaction.isButton() && interaction.customId.startsWith('AbrirTicket_')) {
            valorticket = interaction.customId.replace('AbrirTicket_', '');
            CreateTicket(interaction, valorticket)
        } else if (interaction.isSelectMenu() && interaction.customId === 'abrirticket') {
            valorticket = interaction.values[0]
            CreateTicket(interaction, valorticket)
        }

        if (interaction.isSelectMenu()) {

            if (interaction.customId == 'asdihadbhawhdwhdaw') {


                const campo = interaction.values[0].split('_')[0]
                const produto = interaction.values[0].split('_')[1]


                GerenciarCampos2(interaction, campo, produto, true)

            }

            if (interaction.customId == 'selectautorole') {

                await relikia.set("automod.autorole", interaction.values);
                await autorole(interaction, client);
                interaction.followUp({
                    content: `O sistema de AutoRole foi configurado com sucesso`,
                    ephemeral: true
                });
            }

            if (interaction.customId == 'stockhasdhvsudasd') {

                const campo = interaction.values[0].split('_')[0]
                const produto = interaction.values[0].split('_')[1]

                MessageStock(interaction, 1, produto, campo, true)


            }

            if (interaction.customId == 'deletarticketsfunction') {
                const valordelete = interaction.values
                for (const iterator of valordelete) {
                    tickets.delete(`tickets.funcoes.${iterator}`)
                }
                painelTicket(interaction)
            }



            // buton com customid AbrirTicket





        }


        if (interaction.isChannelSelectMenu()) {

            if (interaction.customId == 'canalpostarticket') {
                await interaction.reply({ content: `🔄 | Aguarde estamos criando sua mensagem!`, ephemeral: true });
                await CreateMessageTicket(interaction, interaction.values[0], client)
                interaction.editReply({ content: `✅ | Mensagem criada com sucesso!`, ephemeral: true });
            }

        }

        if (interaction.isChannelSelectMenu()) {
            if (interaction.customId == 'selectautoclearcanal') {

                await relikia.set("autoclear.channel", interaction.values);
                await AutoClear(interaction, client);
            }

        }

        if (interaction.isRoleSelectMenu()) {

            if (interaction.customId == 'selectautorole') {
                await relikia.set("automod.autorole", interaction.values);
                await autorole(interaction, client);
                interaction.followUp({
                    content: `${interaction.user}`,
                    embeds: [
                        new EmbedBuilder()
                            .setColor(`#2b2d31`)
                            .setDescription(`✅ | Cargo alterado com sucesso.`)
                    ],
                    ephemeral: true
                });
            }

        }


        if (interaction.isButton()) {

            if (interaction.customId == 'sincronizarticket') {
                await interaction.reply({ content: `🔄 | Aguarde estamos atualizando suas mensagem!`, ephemeral: true });
                await Checkarmensagensticket(client)
                interaction.editReply({ content: `✅ | Mensagens atualizada com sucesso!`, ephemeral: true });
            }


            if (interaction.customId == 'arquivar') {

                if (!interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargoadm')) && !interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargosup'))) return interaction.reply({ content: `❌| Você não tem permissão para fazer isso!`, ephemeral: true });

                //  try {
                //    await interaction.message.delete()
                // } catch (error) { 

                // }

                try {
                    // Criar embed para avisar que o canal foi arquivado
                    const embed = new EmbedBuilder()
                        .setTitle('Canal Arquivado')
                        .setDescription('Este canal foi arquivado.');

                    // Criar botões
                    const row = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId('unarchive')
                                .setLabel('Desarquivar')
                                .setEmoji(`1248749695342346372`)
                                .setStyle(3),
                            new ButtonBuilder()
                                .setCustomId('deletar')
                                .setLabel('Deletar')
                                .setEmoji(`1248749181175333027`)
                                .setStyle(4)
                        );

                    // Editar a mensagem da interação para adicionar a embed e os botões
                    await interaction.reply({ embeds: [embed], components: [row] });
                } catch (error) {
                    console.error('Erro ao arquivar o canal:', error);
                }
                await interaction.channel.setArchived(true);
            }

            if (interaction.customId === 'unarchive') {
                try {
                    // Desarquivar o canal
                    await interaction.channel.setArchived(false);

                    // Atualizar a embed para avisar que o canal foi desarquivado
                    const embed = new EmbedBuilder()
                        .setTitle('Canal Desarquivado')
                        .setDescription('Este canal foi desarquivado.');

                    // Remover os botões
                    await interaction.update({ embeds: [embed], components: [] });
                } catch (error) {
                    console.error('Erro ao desarquivar o canal:', error);
                }
            }
            if (interaction.customId == 'deletar') {

                if (!interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargoadm')) && !interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargosup'))) return interaction.reply({ content: `❌| Você não tem permissão para fazer isso!`, ephemeral: true });

                try {
                    interaction.channel.delete()
                } catch (error) {

                }

            }



            if (interaction.customId == `postarticket`) {
                const ggg = tickets.get(`tickets.funcoes`)
                const ggg2 = tickets.get(`tickets.aparencia`)


                if (ggg == null || Object.keys(ggg).length == 0 || ggg2 == null || Object.keys(ggg2).length == 0) {
                    return interaction.reply({ content: `❌Adicione um bloco antes de postar a mensagem.`, ephemeral: true });
                } else {
                    const selectaaa = new Discord.ChannelSelectMenuBuilder()
                        .setCustomId('canalpostarticket')
                        .setPlaceholder('Clique aqui para selecionar')
                        .setChannelTypes(Discord.ChannelType.GuildText)

                    const row1 = new ActionRowBuilder()
                        .addComponents(selectaaa);

                    interaction.reply({ components: [row1], content: `Selecione o canal onde quer postar a mensagem.`, ephemeral: true, })

                }
            }



            if (interaction.customId == 'remfuncaoticket') {


                const ggg = tickets.get(`tickets.funcoes`)



                if (ggg == null || Object.keys(ggg).length == 0) {
                    return interaction.reply({ content: `❌ Não existe nenhum bloco criado para remover.`, ephemeral: true });
                }

                else {

                    const selectMenuBuilder = new Discord.StringSelectMenuBuilder()
                        .setCustomId('deletarticketsfunction')
                        .setPlaceholder('Clique aqui para selecionar')
                        .setMinValues(0)

                    for (const chave in ggg) {
                        const item = ggg[chave];

                        const option = {
                            label: `${item.nome}`,
                            description: `${item.predescricao}`,
                            value: item.nome
                        };

                        selectMenuBuilder.addOptions(option);


                    }

                    selectMenuBuilder.setMaxValues(Object.keys(ggg).length)

                    const style2row = new ActionRowBuilder().addComponents(selectMenuBuilder);
                    try {
                        await interaction.update({ components: [style2row], content: `${interaction.user} Qual funções deseja remover?`, embeds: [] })
                    } catch (error) {
                    }
                }

            }


            if (interaction.customId == 'rendimento') {
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId("todayyyy")
                            .setLabel('Hoje')
                            .setStyle(2)
                            .setDisabled(false),
                        new ButtonBuilder()
                            .setCustomId("7daysss")
                            .setLabel('Últimos 7 dias')
                            .setStyle(2)
                            .setDisabled(false),
                        new ButtonBuilder()
                            .setCustomId("30dayss")
                            .setLabel('Últimos 30 dias')
                            .setStyle(2)
                            .setDisabled(false),
                        new ButtonBuilder()
                            .setCustomId("totalrendimento")
                            .setLabel('Rendimento Total')
                            .setStyle(3)
                            .setDisabled(false),
                    )
                interaction.reply({ content: `Olá senhor **${interaction.user.username}**, selecione algum filtro.`, components: [row], ephemeral: true })
            }

            if (interaction.customId == 'gerenciarposicao') {

                Posicao1(interaction, client)

            }



            if (interaction.customId == 'Editarprimeiraposição') {

                const aa = configuracao.get(`posicoes`)

                const modalaAA = new ModalBuilder()
                    .setCustomId('aslfdjauydvaw769dg7waajnwndjo')
                    .setTitle(`Definir primeira posição`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`VALOR`)
                    .setPlaceholder(`Insira uma quantia, ex: 100`)
                    .setValue(aa?.pos1?.valor == undefined ? '' : aa.pos1?.valor)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)
                h
                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`CARGO`)
                    .setPlaceholder(`Insira um id de algum cargo`)
                    .setValue(aa?.pos1?.role == undefined ? '' : aa.pos1?.role)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);

                modalaAA.addComponents(firstActionRow3, firstActionRow4);

                await interaction.showModal(modalaAA);
            }

            if (interaction.customId == 'Editarsegundaposição') {
                const aa = configuracao.get(`posicoes`)

                const modalaAA = new ModalBuilder()
                    .setCustomId('awiohdbawudwdwhduawdnuaw')
                    .setTitle(`Definir segunda posição`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`VALOR`)
                    .setPlaceholder(`Insira uma quantia, ex: 100`)
                    .setValue(aa?.pos2?.valor == undefined ? '' : aa.pos2?.valor)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`CARGO`)
                    .setPlaceholder(`Insira um id de algum cargo`)
                    .setValue(aa?.pos2?.role == undefined ? '' : aa.pos2?.role)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);

                modalaAA.addComponents(firstActionRow3, firstActionRow4);

                await interaction.showModal(modalaAA);
            }

            if (interaction.customId == 'Editarterceiraposição') {
                const aa = configuracao.get(`posicoes`)
                const modalaAA = new ModalBuilder()
                    .setCustomId('uy82819171h172')
                    .setTitle(`Definir terceira posição`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`VALOR`)
                    .setPlaceholder(`Insira uma quantia, ex: 100`)
                    .setValue(aa?.pos3?.valor == undefined ? '' : aa.pos3?.valor)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`CARGO`)
                    .setPlaceholder(`Insira um id de algum cargo`)
                    .setValue(aa?.pos3?.role == undefined ? '' : aa.pos3?.role)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);

                modalaAA.addComponents(firstActionRow3, firstActionRow4);

                await interaction.showModal(modalaAA);
            }


            if (interaction.customId == 'todayyyy' || interaction.customId == '7daysss' || interaction.customId == '30dayss' || interaction.customId == 'totalrendimento') {

                let rendimento
                let name

                if (interaction.customId == 'todayyyy') {
                    rendimento = await EstatisticasStorm.SalesToday()
                    name = 'Resumo das vendas de hoje'
                } else if (interaction.customId == '7daysss') {
                    rendimento = await EstatisticasStorm.SalesWeek()
                    name = 'Resumo das vendas nos últimos 7 dias'
                } else if (interaction.customId == '30dayss') {
                    rendimento = await EstatisticasStorm.SalesMonth()
                    name = 'Resumo das vendas nos últimos 30 dias'
                } else if (interaction.customId == 'totalrendimento') {
                    name = 'Resumo geral de todas as vendas'
                    rendimento = await EstatisticasStorm.SalesTotal()
                }


                const embed = new EmbedBuilder()
                    .setColor(`${configuracao.get(`Cores.Principal`) == null ? `#635b44` : configuracao.get(`Cores.Principal`)}`) //635b44
                    .setTitle(`${name}`)
                    .addFields(
                        { name: `**Rendimento**`, value: `\`R$ ${Number(rendimento.rendimentoTotal).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\``, inline: true },
                        { name: `**Pedidos aprovados**`, value: `\`${rendimento.quantidadeTotal}\``, inline: true },
                        { name: `**Produtos entregues**`, value: `\`${rendimento.produtosEntregue}\``, inline: true },
                    )
                    .setAuthor({ name: `${interaction.user.username}` })
                    .setTimestamp()
                    .setFooter({ text: `${interaction.user.username}` })

                interaction.update({ embeds: [embed] })
            }



            if (interaction.customId.startsWith('criarrrr')) {

                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111idsjjsdua')
                    .setTitle(`Criação`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`NOME`)
                    .setPlaceholder(`Insira o nome do seu produto`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`DESCRIÇÃO`)
                    .setPlaceholder(`Insira uma descrição para seu produto`)
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(true)
                    .setMaxLength(1024)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`ENTREGA AUTOMÁTICA?`)
                    .setPlaceholder(`Digite "sim" ou "não"`)
                    .setStyle(TextInputStyle.Short)
                    .setMaxLength(3)
                    .setRequired(true)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP4')
                    .setLabel(`ICONE (OPCIONAL)`)
                    .setPlaceholder(`Insira uma URL de uma imagem ou gif`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN6 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`BANNER (OPCIONAL)`)
                    .setPlaceholder(`Insira uma URL de uma imagem ou gif`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);
                const firstActionRow7 = new ActionRowBuilder().addComponents(newnameboteN6);



                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6, firstActionRow7);
                await interaction.showModal(modalaAA);

            }
            /* if (interaction.customId.startsWith('infoauth')) {

                infoauth(interaction, client)

            }

            if (interaction.customId.startsWith('voltarconfigauth')) {

                configauth(interaction, client)

            }

            if (interaction.customId.startsWith('infosauth')) {

                infosauth(interaction, client)

            } 

            if (interaction.customId.startsWith('voltarauth')) {

                ecloud(interaction, client)

            } */


            if (interaction.customId.startsWith('addperms')) {

                addPerm(interaction, client)

            }
            if (interaction.customId.startsWith('criarlojadessecrlh')) {

                CreateStore(interaction, client)

            }

            if (interaction.customId.startsWith('voltar1')) {

                Painel(interaction, client)

            }

            if (interaction.customId.startsWith('painelconfigat')) {

                automatico(interaction, client);

            }

            if (interaction.customId.startsWith('autoclearfr')) {

                AutoClear(interaction, client);

            }

            if (interaction.customId.startsWith('dawda')) {


                interaction.reply({ ephemeral: true, content: `Sistema em manutenção..` })
                /*  interaction.update({
                      content: `
                      `,
                      embeds: [
                          new Discord.EmbedBuilder()
                              .setColor(`#2b2d31`)
                              .setDescription(` Seja bem vindo ao sistema de **AutoClear** do seu bot de vendas, configure utilizando os botões abaixo.`)
                              .addFields(
                                  {
                                      name: `Sistema de **AutoClear ON/OFF**`,
                                      value: `Online`,
                                      inline: true
                                  }
                              )
                      ],
                      components: [
                          new ActionRowBuilder()
                              .addComponents(
                                  new ButtonBuilder()
                                      .setCustomId('automessagefr')
                                      .setLabel('Configurar AutoClear')
                                      .setEmoji(`1240450763595976715`)
                                      .setStyle(2),
                                  new ButtonBuilder()
                                      .setCustomId('voltarautofrcabuloso')
                                      .setEmoji(`1262295432130723842`)
                                      .setStyle(2)
                              )
                      ]
                  }) */

            }
            // if (interaction.customId.startsWith('dawdawdawdawdawd')) {

            //     interaction.update({
            //         content: `
            //         `,
            //         embeds: [
            //             new Discord.EmbedBuilder()
            //                 .setColor(`#2b2d31`)
            //                 .setDescription(` Seja bem vindo as suas ações automaticas`)
            //         ],
            //         components: [
            //             new ActionRowBuilder()
            //                 .addComponents(
            //                     new ButtonBuilder()
            //                         .setCustomId('adwdawd')
            //                         .setLabel('Mensagens Automaticas')
            //                         .setEmoji(`1240450763595976715`)
            //                         .setStyle(2),
            //                     new ButtonBuilder()
            //                         .setCustomId('voltarautofrcabuloso')
            //                         .setEmoji(`1262295432130723842`)
            //                         .setStyle(2)
            //                 )
            //         ]
            //     })

            // }
            // if (interaction.customId.startsWith("frcabulusoacima")) {
            //     mensagemauto(interaction, client);
            // }

            // if (interaction.customId.endsWith("_criarmsgauto")) {
            //     const userid = interaction.user.id;
            //     const modal = new ModalBuilder()
            //         .setTitle("Configurar Embed")
            //         .setCustomId(`criarmsgautomodal`);

            //     const title = new TextInputBuilder()
            //         .setCustomId("title")
            //         .setLabel("envie abaixo o titulo da embed")
            //         .setMaxLength(200)
            //         .setRequired(false)
            //         .setStyle(1)
            //         .setPlaceholder("Titulo Título da Embed");

            //     const desc = new TextInputBuilder()
            //         .setCustomId("desc")
            //         .setLabel("envie abaixo a mensagem")
            //         .setStyle(2)
            //         .setMaxLength(4000)
            //         .setRequired(true)
            //         .setPlaceholder("Descrição da Embed");

            //     const banner = new TextInputBuilder()
            //         .setCustomId("banner")
            //         .setLabel("envie o banner")
            //         .setStyle(1)
            //         .setRequired(false)
            //         .setPlaceholder("Banner da Embed");

            //     const channel = new TextInputBuilder()
            //         .setCustomId("channel")
            //         .setStyle(1)
            //         .setLabel("envie o id do canal que será enviado")
            //         .setPlaceholder("Canal que será enviado a mensagem")
            //         .setRequired(true);

            //     const time = new TextInputBuilder()
            //         .setCustomId("time")
            //         .setLabel("Quanto tempo? (em segundos)")
            //         .setMaxLength(3)
            //         .setPlaceholder("Quanto tempo será enviado a mensagem?")
            //         .setStyle(1)
            //         .setRequired(true);

            //     modal.addComponents(new ActionRowBuilder().addComponents(title));
            //     modal.addComponents(new ActionRowBuilder().addComponents(desc));
            //     modal.addComponents(new ActionRowBuilder().addComponents(banner));
            //     modal.addComponents(new ActionRowBuilder().addComponents(channel));
            //     modal.addComponents(new ActionRowBuilder().addComponents(time));

            //     return interaction.showModal(modal);
            // }

            // if (interaction.customId.endsWith("dadwa")) {
            //     const title = interaction.fields.getTextInputValue("title") || null;
            //     const desc = interaction.fields.getTextInputValue("desc");
            //     const banner = interaction.fields.getTextInputValue("banner") || null;
            //     const channel = interaction.fields.getTextInputValue("channel");
            //     const time = parseInt(interaction.fields.getTextInputValue("time"));
            //     const chnchk = interaction.guild.channels.cache.get(channel);
            //     if (!chnchk) return interaction.reply({ content: `❌ | Não existe um canal com ID dê \`${channel}\``, ephemeral: true });
            //     if (isNaN(time)) return interaction.reply({ content: `❌ | Coloque apenas numeros na quantidade de Segundos`, ephemeral: true });
            //     if (time < 1) return interaction.reply({ content: `${emoji(12)} | Coloque acima de \`1 Segundo\``, ephemeral: true });
            //     await interaction.deferUpdate();
            //     try {
            //         await interaction.followUp({
            //             content: `${interaction.user}`,
            //             embeds: [
            //                 new EmbedBuilder()
            //                     .setAuthor({ name: "Previa da Embed" })
            //                     .setTitle(title)
            //                     .setDescription(desc)
            //                     .setColor(await relikia.get("cor"))
            //                     .setImage(banner)
            //             ],
            //             components: [
            //                 new ActionRowBuilder()
            //                     .addComponents(
            //                         new ButtonBuilder()
            //                             .setCustomId("oasidnmasiod123asniud")
            //                             .setLabel("Mensagem Automatica")
            //                             .setStyle(2)
            //                             .setDisabled(true)
            //                     )
            //             ],
            //             ephemeral: true
            //         }).then(async () => {
            //             await relikia.push("automod.mensagem_auto.mensagem", {
            //                 title,
            //                 desc,
            //                 banner,
            //                 channel,
            //                 tempo: Number(time),
            //                 ind: Number(await relikia.get("automod.mensagem_auto.mensagem").length + 1)
            //             });
            //             const mensagem = await relikia.get("automod.mensagem_auto");
            //             const status = !mensagem.system ? "`Ativada`" : "`Desativada`";
            //             let ok = mensagem.mensagem.map((a, index) => { return `(\`${index + 1}\`) - ${a.desc}` })
            //                 .join("\n");
            //             if (mensagem.mensagem.length <= 0) {
            //                 ok = "Nenhuma mensagem definida!";
            //             };
            //             const userid = interaction.user.id;
            //             mensagemauto(interaction, client);
            //         })
            //     } catch (err) {
            //         interaction.followUp({
            //             content: `${emoji(29)} | Ocorreu um erro...\n\n**Mensagem do erro:** \`\`\`${err.message}\`\`\``,
            //             ephemeral: true
            //         })
            //     }
            // }
            // if (interaction.customId.endsWith("_removermsgauto")) {
            //     const modal = new ModalBuilder()
            //         .setCustomId(`deletemsgautomodal`)
            //         .setTitle("Configurar Mensagem Automatica");

            //     const text = new TextInputBuilder()
            //         .setCustomId("text")
            //         .setStyle(1)
            //         .setMaxLength(3)
            //         .setRequired(true)
            //         .setPlaceholder("Envie apenas numeros.")
            //         .setLabel("qual mensagem deseja retirar?");

            //     modal.addComponents(new ActionRowBuilder().addComponents(text));

            //     return interaction.showModal(modal);
            // }
            // if (interaction.customId.startsWith("deletemsgautomodal")) {
            //     const text = parseInt(interaction.fields.getTextInputValue("text"));
            //     const valor = text - 1;
            //     if (isNaN(text)) return interaction.reply({ content: `❌ | Coloque apenas numeros.`, ephemeral: true });
            //     if (text <= 0) return interaction.reply({ content: `❌ | Coloque um Valor Acima de \`0\`.`, ephemeral: true });
            //     if (valor > await relikia.get("automod.mensagem_auto.mensagem").length) return interaction.reply({ content: `❌ | Coloque um Valor Abaixo dê \`${await relikia.get("automod.mensagem_auto.mensagem").length}\`.`, ephemeral: true });
            //     const a = await relikia.get("automod.mensagem_auto.mensagem");
            //     await a.splice(Number(valor), 1)[0];
            //     await relikia.set("automod.mensagem_auto.mensagem", a);
            //     mensagemauto(interaction, client);
            // }
            // if (interaction.customId.endsWith("onoffmsgauto")) {
            //     const userid = interaction.user.id;
            //     const mensagem = await relikia.get("automod.mensagem_auto");
            //     const status = !mensagem.system ? "`Ativada`" : "`Desativada`";
            //     let ok = mensagem.mensagem.map((a, index) => { return `(\`${index + 1}\`) - ${a.desc}` })
            //         .join("\n");
            //     if (mensagem.mensagem.length <= 0) {
            //         ok = "Nenhuma mensagem definida!";
            //     };
            //     await relikia.set("automod.mensagem_auto.system", !mensagem.system);
            //     await interaction.update({
            //         embeds: [
            //             new EmbedBuilder()
            //                 .setTitle("Mensagens Automáticas")
            //                 .addFields(
            //                     { name: `**Mensagens Automaticas:**`, value: `${status}`, incline: true }
            //                 )
            //                 .setDescription(`➡️** | Mensagens Automaticas:**\n${ok}`)
            //                 .setColor("#2b2d31")
            //                 .setThumbnail(interaction.client.user.displayAvatarURL())
            //                 .setTimestamp()
            //                 .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
            //                 .setAuthor({ name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL() })
            //         ],
            //         components: [
            //             new ActionRowBuilder()
            //                 .addComponents(
            //                     new ButtonBuilder()
            //                         .setCustomId(`${userid}_criarmsgauto`)
            //                         .setLabel("Criar Mensagem Automática")
            //                         .setEmoji("<:mais:1237422815473434644>")
            //                         .setStyle(1),
            //                     new ButtonBuilder()
            //                         .setCustomId(`${userid}_removermsgauto`)
            //                         .setLabel("Remover Mensagem Automática")
            //                         .setEmoji("<:menos2:1262295420181286963> ")
            //                         .setStyle(1),
            //                 ),
            //             new ActionRowBuilder()
            //                 .addComponents(
            //                     new ButtonBuilder()
            //                         .setCustomId(`onoffmsgauto`)
            //                         .setLabel("Ativar/Desativar Mensagens")
            //                         .setEmoji("<:airbots:1251227294362505307>")
            //                         .setStyle(2),
            //                     new ButtonBuilder()
            //                         .setCustomId(`voltarautofrcabuloso`)
            //                         .setStyle(2)
            //                         .setEmoji("⬅")
            //                 )
            //         ]
            //     })
            // }

            if (interaction.customId.endsWith("autoclearcanal")) {
                interaction.update({
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new Discord.ChannelSelectMenuBuilder()
                                    .setCustomId(`selectautoclearcanal`)
                                    .setMaxValues(7)
                                    .setPlaceholder("Selecione abaixo qual será o CANAL que sera usado o AUTOCLEAR")
                            ),
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setCustomId(`voltarautofrcabuloso`)
                                    .setStyle(2)
                                    .setEmoji("1237422652050899084")
                            )
                    ]
                })
            }
            if (interaction.customId.endsWith("autocleartempo")) {
                const canalautoclear = await relikia.get("autoclear.channel");
                const tempoclear = await relikia.get("autoclear.time")
                await interaction.update({ embeds: [], content: 'Por favor, insira o tempo em segundos:', components: [], ephemeral: true });

                const filter = m => m.author.id === interaction.user.id;
                const timeCollector = interaction.channel.createMessageCollector({ filter, max: 1, time: 60000 });

                timeCollector.on('collect', async (message) => {
                    const time = parseInt(message.content);
                    if (isNaN(time) || time < 10) {
                        return interaction.followUp({ content: 'Tempo inválido, deve ser um número maior que 10 segundos.', ephemeral: true });
                    }

                    // Usando relikia.set para atualizar autoclear.time
                    relikia.set("autoclear.time", time);

                    timeout = time * 1000;

                    message.delete();
                    interaction.editReply({
                        content: ``, embeds: [
                            new Discord.EmbedBuilder()
                                .setTitle(`Configurando \`AutoClear\``)
                                .setDescription(` você acessou a aba de **AutoClear**, suas **informações** mais os **botões de configurações** estão aqui em baixo. **Configure tudo!**`)
                                .addFields(
                                    {
                                        name: `🚪 | Canal AutoClear:`,
                                        value: canalautoclear ? `<#${canalautoclear}>` : 'Nenhum canal selecionado',
                                        inline: true
                                    },
                                    {
                                        name: `⏰ | Tempo AutoClear:`,
                                        value: `${time} segundos`,
                                        inline: true
                                    },
                                )
                        ],
                        components: [
                            new Discord.ActionRowBuilder()
                                .addComponents(
                                    new Discord.ButtonBuilder()
                                        .setCustomId(`autoclearcanal`)
                                        .setLabel("Configurar Canal")
                                        .setEmoji("1262295420181286963")
                                        .setStyle(2),
                                    new Discord.ButtonBuilder()
                                        .setCustomId(`autocleartempo`)
                                        .setLabel("Configurar Tempo")
                                        .setEmoji("1207761646152458351")
                                        .setStyle(2),
                                ),
                            new Discord.ActionRowBuilder()
                                .addComponents(
                                    new Discord.ButtonBuilder()
                                        .setCustomId('iniciarautoclear')
                                        .setLabel('Ligar AutoClear')
                                        .setEmoji(`1248749835109011468`)
                                        .setStyle(1),
                                    new Discord.ButtonBuilder()
                                        .setCustomId('pararautoclear')
                                        .setLabel('Desligar AutoClear')
                                        .setEmoji(`1248749849466376333`)
                                        .setStyle(2),
                                    new Discord.ButtonBuilder()
                                        .setCustomId('voltarautofrcabuloso')
                                        .setEmoji('1237422652050899084')
                                        .setStyle(2)
                                )
                        ], ephemeral: true
                    });
                });
            }


            if (interaction.customId.endsWith("iniciarautoclear")) {
                const canalAutoClear = await relikia.get("autoclear.channel");
                const tempoAutoClear = await relikia.get("autoclear.time");

                if (!canalAutoClear) {
                    await interaction.reply({ content: 'Canal AutoClear não configurado.', ephemeral: true });
                    return;
                }
                setInterval(async () => {
                    const channel = await interaction.guild.channels.fetch(canalAutoClear);
                    if (channel) {
                        await channel.bulkDelete(100);
                    }
                }, tempoAutoClear * 1000);

                await interaction.reply({
                    content: `${interaction.user}`,
                    embeds: [
                        new EmbedBuilder()
                            .setDescription(`✅ | Seu AutoClear foi iniciado corretamente no canal <#${canalAutoClear}>`)
                    ],
                    ephemeral: true
                });
            }

            if (interaction.customId.endsWith("pararautoclear")) {

                const canalautoclear = await relikia.get("autoclear.channel");
                const tempoclear = await relikia.get("autoclear.time")

                try {
                    await relikia.delete("autoclear.channel");
                    relikia.set("autoclear.time", 10);
                    await interaction.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setColor(`#2b2d31`)
                                .setDescription(`✅ | Seu AutoClear foi parado e as configurações foram resetadas.`)
                        ],
                        content: `${interaction.user}`,
                        ephemeral: true

                    });
                } catch (error) {
                    await interaction.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setColor(`#2b2d31`)
                                .setDescription(`❌ | Ocorreu um erro ao parar o AutoClear.`)
                        ],
                        content: `${interaction.user}`,
                        ephemeral: true

                    });
                }
            }


            if (interaction.customId.startsWith('voltarautofrcabuloso')) {

                automatico(interaction, client)

            }

            if (interaction.customId.endsWith('_addcargoentrar')) {
                const userid = interaction.user.id;
                interaction.update({
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new RoleSelectMenuBuilder()
                                    .setCustomId(`selectautorole`)
                                    .setMaxValues(7)
                                    .setPlaceholder("Selecione abaixo qual será o CARGO vai dar AUTOMATICAMENTE")
                            ),
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setCustomId(`voltarcrlh`)
                                    .setStyle(2)
                                    .setEmoji("1237422652050899084")
                            )
                    ]
                })
            }

            if (interaction.customId.endsWith('autorolecaralho')) {
                autorole(interaction, client);
            }

            if (interaction.customId.endsWith('voltarcrlh')) {
                autorole(interaction, client);
            }



            if (interaction.customId.endsWith('paineladmin')) {
                Painel(interaction, client);
            }



            if (interaction.customId.endsWith('voltarpainelprincipal')) {
                PainelPrincipal(interaction, client);
            }


            if (interaction.customId.endsWith('_resetautoroles')) {
                const userid = interaction.user.id;
                await relikia.set("automod.autorole", []);
                await autorole(interaction, client);
                interaction.followUp({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription(`✅ | O sistema de AutoRole foi resetado com sucesso`)
                            .setColor(`#2b2d31`)
                    ],
                    content: ``,
                    ephemeral: true
                });

            }

            if (interaction.customId.startsWith('sistemadebackupconfig')) {
                interaction.update({
                    content: `${interaction.user} Está área está em manutenção, botões desativados.`,
                    embeds: [
                        new Discord.EmbedBuilder()
                            .setTitle(`Recupere seu servidor`)
                            .setDescription(` com está função você pode fazer um **backup do seu servidor**, que ira copiar, seu canais, cargos e etc. Resumindo ira salvar seu servidor caso caia.\n- **Fazer Backup**\n - Com este **botão** você ira salvar seu servidor. Ira levar de 1 á 10 minutos então tenha paciencia.\n- **Recuperar Servidor**\n - Com este botão você pode utiliza após seu servidor cair e tudo que você salvou, ira recuperar.`)
                            .setColor('#2b2d31')
                            .setFooter({ text: `Backup do seu servidor.` }),
                        new Discord.EmbedBuilder()
                            .setDescription(`- **Deseja salvar seus membros caso seu servidor caia?**\n - Adquira o melhor **Oauth2** no nosso servidor **https://discord.gg/9VAfMk44Ju**!`)
                            .setColor('#2b2d31')
                    ],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setCustomId('backup')
                                    .setLabel('Fazer Backup')
                                    .setEmoji(`1240455964436467743`)
                                    .setDisabled(true)
                                    .setStyle(1),
                                new ButtonBuilder()
                                    .setCustomId('restaurar')
                                    .setLabel('Recuperar Servidor')
                                    .setEmoji(`1240455950045937715`)
                                    .setDisabled(true)
                                    .setStyle(2),
                                new ButtonBuilder()
                                    .setCustomId('voltar1')
                                    .setEmoji(`1262295432130723842`)
                                    .setStyle(2)
                            )
                    ]
                })
            }

            const sqlite3 = require('sqlite3').verbose();
            let db = new sqlite3.Database('./server_backup.db', (err) => {
            });

            db.run(`CREATE TABLE IF NOT EXISTS server_backup (
                server_id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            )`);


            if (interaction.customId.startsWith('backup')) {
                interaction.deferUpdate();

                let serverData = {
                    channels: [],
                    roles: []
                };
                interaction.reply({ content: 'Backup do servidor salvo com sucesso!', ephemeral: true });
                if (!interaction.guild) {
                    return interaction.followUp({ content: 'Guild não encontrada.', ephemeral: true });
                }

                interaction.guild.channels.cache.forEach(channel => {
                    serverData.channels.push({
                        id: channel.id,
                        name: channel.name,
                        type: channel.type,
                        parent: channel.parentId,
                        permissionOverwrites: channel.permissionOverwrites.cache.map(po => ({
                            id: po.id,
                            type: po.type,
                            allow: po.allow.toArray(),
                            deny: po.deny.toArray()
                        }))
                    });
                });

                interaction.guild.roles.cache.forEach(role => {
                    serverData.roles.push({
                        id: role.id,
                        name: role.name,
                        color: role.color,
                        hoist: role.hoist,
                        permissions: role.permissions.toArray(),
                        position: role.position
                    });
                });

                db.run(`INSERT OR REPLACE INTO server_backup (server_id, data) VALUES (?, ?)`, [interaction.guild.id, JSON.stringify(serverData)], function (err) {
                    if (err) {
                        return console.log(err.message);
                    }
                    interaction.followUp({ content: 'Backup do servidor salvo com sucesso!', ephemeral: true });
                });
            }

            if (interaction.customId.startsWith('restaurar')) {
                interaction.deferUpdate();

                db.get(`SELECT data FROM server_backup WHERE server_id = ?`, [interaction.guild.id], async (err, row) => {
                    if (err) {
                        return console.log(err.message);
                    }
                    if (!row) {
                        return interaction.followUp({ content: 'Nenhum backup encontrado para este servidor.', ephemeral: true });
                    }

                    let serverData = JSON.parse(row.data);

                    for (const roleData of serverData.roles) {
                        await interaction.guild.roles.create({
                            name: roleData.name,
                            color: roleData.color,
                            hoist: roleData.hoist,
                            permissions: roleData.permissions,
                            position: roleData.position
                        });
                    }

                    for (const channelData of serverData.channels) {
                        let channel = await interaction.guild.channels.create({
                            name: channelData.name,
                            type: channelData.type,
                            parent: channelData.parent
                        });

                        for (const po of channelData.permissionOverwrites) {
                            await channel.permissionOverwrites.create(po.id, {
                                allow: po.allow,
                                deny: po.deny
                            });
                        }
                    }

                    interaction.followUp({ content: 'Servidor restaurado com sucesso!', ephemeral: true });
                });
            }




            if (interaction.customId.startsWith('permsbotfrcabuloso')) {

                interaction.update({
                    content: ``,
                    embeds: [
                        new Discord.EmbedBuilder()
                            .setTitle(`Configuração das permissões`)
                            .setDescription(` agora você está configurando as permições do relikia, utilize o \`adicionar\` para **adicionar** um usuario com **perms no seu bot**, utilize o \`remover\` para **remover** um usuario com **perm da sua database.**`)
                            .setColor('#2b2d31')
                            .setFooter({ text: `Adicione e remova perms.` })
                    ],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setCustomId('adicionar')
                                    .setLabel('Adicionar Usuario')
                                    .setEmoji(`1241444365608550491`)
                                    .setStyle(3),
                                new ButtonBuilder()
                                    .setCustomId('remover')
                                    .setLabel('Remover Usuario')
                                    .setEmoji(`1241444364035690547`)
                                    .setStyle(4),
                                new ButtonBuilder()
                                    .setCustomId('voltar1')
                                    .setEmoji(`1262295432130723842`)
                                    .setStyle(2)
                            )
                    ]
                })

            }

            if (interaction.customId.startsWith('adicionar')) {
                interaction.deferUpdate();
                interaction.channel.send(`Qual é o id do usuário que você quer dar permissão?`).then(msg => {
                    const filter = m => m.author.id === interaction.user.id;
                    const collector = msg.channel.createMessageCollector({ filter, max: 1, time: 120000 }); // Definindo o tempo limite para 2 minutos (120000 milissegundos)
                    collector.on("collect", message => {
                        message.delete();
                        const user = message.content;
                        perms.set(`${user}`, user);
                        msg.edit(`Permissão adicionada para o usuário!`).then((editedMessage) => {
                            setTimeout(() => {
                                editedMessage.delete().catch(console.error);
                            }, 2500);
                        });
                    });
                });
            }

            if (interaction.customId.startsWith('remover')) {
                interaction.deferUpdate();
                interaction.channel.send(`Qual é o id do usuário que você quer tirar permissão?`).then(msg => {
                    const filter = m => m.author.id === interaction.user.id;
                    const collector = msg.channel.createMessageCollector({ filter, max: 1, time: 120000 }); // Definindo o tempo limite para 2 minutos (120000 milissegundos)
                    collector.on("collect", message => {
                        message.delete();
                        const user = message.content;
                        perms.delete(`${user}`);
                        msg.edit(`Permissão removida do usuário!`).then((editedMessage) => {
                            setTimeout(() => {
                                editedMessage.delete().catch(console.error);
                            }, 2500);
                        });

                        const embednew = new Discord.EmbedBuilder()
                            .setTitle(`Configuração das permissões`)
                            .setDescription(` agora você está configurando as permições do relikia, utilize o \`adicionar\` para **adicionar** um usuario com **perms no seu bot**, utilize o \`remover\` para **remover** um usuario com **perm da sua database.**`)
                            .setColor('#2b2d31')
                            .setFooter({ text: `Adicione e remova perms.` })
                        embed.edit({ embeds: [embednew] });
                    });
                });
            }

            if (interaction.customId.startsWith('addemojisnessaporra')) {
                interaction.deferUpdate();
                configuracao.set('Emojis_EntregAbaixo', []);
                configuracao.set('Emojis_EntregAuto', []);

                const emojiArray = [
                    "https://cdn.discordapp.com/emojis/1183841001824067676.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1183841127661580339.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1183841205839220776.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1183841312018026556.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1183841529148739669.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1183841627425476621.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1183841719976996885.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1183841795864535151.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1183841842467446844.webp?size=96&quality=lossless"
                ];

                const arrayVendasAuto = [
                    "https://cdn.discordapp.com/emojis/1194131420499677317.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1194131444797288549.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1194131474534899753.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1194131507858636961.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1194131544764317736.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1194131583767162960.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1194131629812220005.webp?size=96&quality=lossless",
                    "https://cdn.discordapp.com/emojis/1194131674196344922.webp?size=96&quality=lossless",
                ];

                const createEmojis = async (emojiUrls, prefix, configKey) => {
                    for (let index = 0; index < emojiUrls.length; index++) {
                        const url = emojiUrls[index];
                        try {
                            const emojiName = `${prefix}${index + 1}`;
                            const createdEmoji = await interaction.guild.emojis.create({ attachment: url, name: emojiName });
                            await configuracao.push(configKey, { id: createdEmoji.id, name: createdEmoji.name });
                        } catch (error) {
                            console.log(error);
                        }
                    }
                };


                Promise.all([
                    createEmojis(emojiArray, 'eb', 'Emojis_EntregAbaixo'),
                    createEmojis(arrayVendasAuto, 'ea', 'Emojis_EntregAuto')
                ]).then(() => {
                    interaction.channel.send('✅ | Emojis adicionados com sucesso! (reinicie o bot para funcionar todos os emojis corretamente!)');
                    Gerenciar2();
                }).catch(error => {
                    console.log(error);
                    interaction.reply('Ocorreu um erro ao adicionar os emojis.');
                });
            }





            if (interaction.customId.startsWith('addfuncaoticket')) {

                const dd = tickets.get('tickets.funcoes')


                if (dd && Object.keys(dd).length > 24) {
                    return interaction.reply({ content: `❌| Você não pode criar mais de 24 funções em seu TICKET!` });
                }

                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111231idsj1233js123dua123')
                    .setTitle(`Adicionar bloco`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`NOME DO BLOCO`)
                    .setPlaceholder(`Insira aqui um nome, como: Suporte`)
                    .setStyle(TextInputStyle.Short)

                    .setRequired(true)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP4')
                    .setLabel(`PRÉ DESCRIÇÃO`)
                    .setPlaceholder(`Insira aqui uma pré descrição, ex: "Preciso de suporte."`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setMaxLength(99)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`DESCRIÇÃO`)
                    .setPlaceholder(`Insira aqui a descrição do bloco.`)
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(false)
                    .setMaxLength(99)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`BANNER (OPCIONAL)`)
                    .setPlaceholder(`Insira aqui uma URL de uma imagem ou GIF`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN6 = new TextInputBuilder()
                    .setCustomId('tokenMP6')
                    .setLabel(`EMOJI DO BLOCO`)
                    .setPlaceholder(`Insira um nome ou id de um emoji do servidor.`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);
                const firstActionRow7 = new ActionRowBuilder().addComponents(newnameboteN6);


                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6, firstActionRow7);
                await interaction.showModal(modalaAA);

            }


            if (interaction.customId.startsWith('definiraparencia')) {



                const modalaAA = new ModalBuilder()
                    .setCustomId('0-89du0awd8awdaw8daw')
                    .setTitle(`Editar Ticket`);

                const dd = tickets.get(`tickets.aparencia`)

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`TITULO`)
                    .setPlaceholder(`Insira aqui um nome, como: Entrar em contato`)
                    .setStyle(TextInputStyle.Short)
                    .setValue(dd?.title == undefined ? '' : dd.title)
                    .setRequired(true)


                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`DESCRIÇÃO`)
                    .setPlaceholder(`Insira aqui uma descrição.`)
                    .setStyle(TextInputStyle.Paragraph)
                    .setValue(dd?.description == undefined ? '' : dd.description)
                    .setMaxLength(500)
                    .setRequired(true)


                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`BANNER (OPCIONAL)`)
                    .setPlaceholder(`Insira aqui uma URL de uma imagem ou GIF`)
                    .setStyle(TextInputStyle.Short)
                    .setValue(dd?.banner == undefined ? '' : dd.banner)
                    .setRequired(false)



                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`COR DO EMBED (OPCIONAL)`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: FFFFFF`)
                    .setStyle(TextInputStyle.Short)
                    .setValue(dd?.color == undefined ? '' : dd.color)
                    .setRequired(false)


                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);

                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6);
                await interaction.showModal(modalaAA);



            }

            if (interaction.customId.startsWith('painelconfigticket')) {


                painelTicket(interaction)


            }



            if (interaction.customId.startsWith('personalizarbot')) {

                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111231idsjjs123dua123')
                    .setTitle(`Editar perfil do bot`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`NOME DE USUÁRIO`)
                    .setValue(`${client.user.username}`)
                    .setPlaceholder(`Insira um nome de usuário (só pode mudar 3x por hora)`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`AVATAR`)
                    .setPlaceholder(`Insira uma URL de um ícone`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`STATUS 1`)
                    .setPlaceholder(`Insira aqui um status personalizado`)
                    //.setValue(`COLOCA AQUI O STATUS 1`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`STATUS 2`)
                    //.setValue(`COLOCA AQUI O STATUS 2`)
                    .setPlaceholder(`Insira aqui um status personalizado`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);

                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6);
                await interaction.showModal(modalaAA);

            }


            if (interaction.customId.startsWith('coresembeds')) {

                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111idsjjs123dua123')
                    .setTitle(`Editar cores dos embeds`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`COR PRINCIPAL`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #Obd4cd`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`COR DE PROCESSAMENTO`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #fcba03`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`COR DE SUCESSO`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #39fc03`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`COR DE FALHA`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #ff0000`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN6 = new TextInputBuilder()
                    .setCustomId('tokenMP6')
                    .setLabel(`COR DE FINALIZADO`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #7363ff`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);
                const firstActionRow7 = new ActionRowBuilder().addComponents(newnameboteN6);



                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6, firstActionRow7);
                await interaction.showModal(modalaAA);

            }



            if (interaction.customId.startsWith('voltar2')) {

                Gerenciar(interaction, client)

            }
            if (interaction.customId.startsWith('ecloud')) {
                ecloud(interaction, client)
            }

            /* 
             if (interaction.customId.startsWith('configauth')) {
                 configauth(interaction, client)
             } */

            if (interaction.customId.startsWith('gerenciarconfigs')) {
                Gerenciar(interaction, client)
            }

            if (interaction.customId.startsWith('configcargos')) {
                ConfigRoles(interaction, client)
            }
            if (interaction.customId.startsWith('painelpersonalizar')) {


                const row2 = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId("coresembeds")
                            .setLabel('Editar cores')
                            .setEmoji(`1178080366871973958`)
                            .setStyle(2),

                        new ButtonBuilder()
                            .setCustomId("personalizarbot")
                            .setLabel('Personalizar Bot')
                            .setEmoji(`1178080828933283960`)
                            .setStyle(2),
                    )

                const row3 = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId("voltar1")
                            .setEmoji(`1262295432130723842`)
                            .setStyle(2)
                    )

                interaction.update({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle(`Personalização do seu Bot`)
                            .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
                            .setDescription(`-  você acessou minha aba de personalizações. Configure suas personalizações abaixo.`)
                    ], components: [row2, row3], content: ``
                })


            }
            if (interaction.customId.startsWith('requestImage')) {

                marcaqr(interaction, client)

            }
            if (interaction.customId.startsWith('painelmod')) {

                const emebde12312 = new EmbedBuilder()
                    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc' : configuracao.get('Cores.Principal')}`)
                    .setDescription(` você está **configurando** meu **sistema** de modereção, **caso queira** alterar algo todas as opções estão aqui em baixo.`)
                const row2 = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId("painelconfigbv")
                            .setLabel('Configurar Boas Vindas')
                            .setEmoji(`1243360025397821482`)
                            .setStyle(1),
                        new ButtonBuilder()
                            .setCustomId("personalizarantifake")
                            .setLabel('Configurar Anti-Fake')
                            .setEmoji(`1242247078479007925`)
                            .setStyle(1),
                        new ButtonBuilder()
                            .setCustomId("voltar1")
                            .setEmoji(`1262295432130723842`)
                            .setStyle(2),
                    )

                interaction.update({ embeds: [emebde12312], components: [row2] })


            }
            if (interaction.customId.startsWith('painelconfigbv')) {

                msgbemvindo(interaction, client)

            }

            if (interaction.customId.startsWith('voltar3')) {

                Gerenciar2(interaction, client)

            }

            if (interaction.customId.startsWith('voltar00')) {

                Painel(interaction, client)

            }


            if (interaction.customId.startsWith('painelconfigvendas')) {


                Gerenciar2(interaction, client)





            }



        }
    }
}