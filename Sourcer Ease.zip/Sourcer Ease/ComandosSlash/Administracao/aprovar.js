const { JsonDatabase } = require("wio.db");
const dbPerms = new JsonDatabase({ databasePath: "./DataBaseJson/perm.json" });
const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const startTime = Date.now();
const maxMemory = 100;
const usedMemory = process.memoryUsage().heapUsed / 1024 / 1024;
const memoryUsagePercentage = (usedMemory / maxMemory) * 100;
const roundedPercentage = Math.min(100, Math.round(memoryUsagePercentage));
const { Painel } = require("../../Functions/Painel");
const { pedidos, pagamentos, carrinhos, configuracao, produtos } = require("../../DataBaseJson");

module.exports = {
  name: "aprovar",
  description: "Use para aprovar manualmente",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction, message) => {

        // user without permission for dbPerms (wio.db)
        if (!dbPerms.has(interaction.user.id)) {
            await interaction.reply({
                content: `❌ | Você não tem permissão para usar este comando.`,
                ephemeral: true
            });
            return;
        };

    if (carrinhos.has(interaction.channel.id) == false) return interaction.reply({ content: `❌Não há um carrinho aberto neste canal.`, ephemeral: true })


    const yy = await carrinhos.get(interaction.channel.id)

    const hhhh = produtos.get(`${yy.infos.produto}.Campos`)
    const gggaaa = hhhh.find(campo22 => campo22.Nome === yy.infos.campo)


    let valor = 0

    if (yy.cupomadicionado !== undefined) {
      const valor2 = gggaaa.valor * yy.quantidadeselecionada

      const hhhh2 = produtos.get(`${yy.infos.produto}.Cupom`)
      const gggaaaawdwadwa = hhhh2.find(campo22 => campo22.Nome === yy.cupomadicionado)
      valor = valor2 * (1 - gggaaaawdwadwa.desconto / 100);
    } else {
      valor = gggaaa.valor * yy.quantidadeselecionada
    }







    const dsfjmsdfjnsdfj = new EmbedBuilder()

    pagamentos.set(`${interaction.channel.id}`, { pagamentos: { id: `Aprovado Manualmente`, method: `pix`, data: Date.now() } })
    interaction.reply({ content: `✅ Pagamento aprovado manualmente. Aguarde..`, ephemeral: true })

  }
}
