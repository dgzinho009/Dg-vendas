const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { MessageStock } = require("../../Functions/ConfigEstoque.js");
const { configuracao } = require("../../DataBaseJson");
const { EstatisticasStorm } = require("../../index.js");
const { JsonDatabase } = require("wio.db");
const dbPerms = new JsonDatabase({ databasePath: "./DataBaseJson/perm.json" });

module.exports = {
  name: "vincular_clientes",
  description: "Vincular clientes ao seu servidor",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction, message) => {
    if (!dbPerms.has(interaction.user.id)) {
      await interaction.reply({
        content: `❌ | Você não tem permissão para usar este comando.`,
        ephemeral: true
      });
      return;
    };

    const button = new ButtonBuilder()
      .setCustomId('start_sync')
      .setLabel('Iniciar Sincronização')
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder()
      .addComponents(button);

    await interaction.reply({
      content: 'Clique no botão abaixo para iniciar a sincronização dos clientes.',
      components: [row],
      ephemeral: true
    });

    const filter = i => i.customId === 'start_sync' && i.user.id === interaction.user.id;

    const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
      if (i.customId === 'start_sync') {
        await i.update({ content: 'Processo de sincronização de clientes foi iniciado.', components: [], ephemeral: true });

        const aa = configuracao.get(`ConfigRoles.cargoCliente`);
        const clientes = await EstatisticasStorm.GuildClients();
        let clientesSetadosComSucesso = 0;

        await Promise.all(clientes.map(async iterator => {
          try {
            const member = await interaction.guild.members.fetch(iterator);
            if (member) {
              await member.roles.add(aa);
              clientesSetadosComSucesso++;
            }
          } catch (error) {
            console.error(error);
          }
        }));

        await i.editReply({ content: `✅ | Processo de sincronização de clientes concluído. ${clientesSetadosComSucesso} usuários foram sincronizados com sucesso.`, components: [], ephemeral: true });
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        interaction.editReply({ content: 'O tempo para iniciar a sincronização expirou.', components: [], ephemeral: true });
      }
    });
  }
}
